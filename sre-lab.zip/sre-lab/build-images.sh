#!/usr/bin/env bash
# Build both images and load them into k3s's containerd (no registry needed).
set -euo pipefail
cd "$(dirname "$0")"
BUILDER="${BUILDER:-docker}"   # or: BUILDER=podman
for img in demo-app ansible-webhook; do
  echo ">> building sre-lab/$img:1.0"
  $BUILDER build -t "sre-lab/$img:1.0" "./$img"
  $BUILDER save "sre-lab/$img:1.0" | sudo k3s ctr -n k8s.io images import -
done
echo "Images loaded into k3s."
