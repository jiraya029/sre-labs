"""SRE lab demo app: tiny instrumented Flask service."""
import logging
import os
import random
import time

from flask import Flask, Response, jsonify, request
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("demo-app")

ERROR_RATE = float(os.getenv("ERROR_RATE", "0.3"))  # chance /error returns HTTP 500
UNTRACKED = {"/metrics", "/health"}

REQUESTS = Counter("http_requests_total", "Total HTTP requests", ["method", "endpoint", "status"])
LATENCY = Histogram(
    "http_request_duration_seconds",
    "HTTP request latency in seconds",
    ["endpoint"],
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5),
)


@app.before_request
def _start_timer():
    request._start = time.perf_counter()


@app.after_request
def _record(resp):
    if request.path not in UNTRACKED:
        REQUESTS.labels(request.method, request.path, str(resp.status_code)).inc()
        LATENCY.labels(request.path).observe(time.perf_counter() - request._start)
    return resp


@app.route("/")
def index():
    # a little CPU work so load tests actually move CPU utilisation (HPA demo)
    sum(i * i for i in range(20000))
    return jsonify(message="Welcome to the SRE lab demo app", status="ok")


@app.route("/error")
def error():
    if random.random() < ERROR_RATE:
        log.error("simulated failure on /error")
        return jsonify(message="simulated failure", status="error"), 500
    return jsonify(message="ok", status="ok")


@app.route("/health")
def health():
    return jsonify(status="healthy")


@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    # Flask dev server on purpose: it does not handle SIGTERM gracefully,
    # which is the cosmetic "Error" status noted in test K6.
    app.run(host="0.0.0.0", port=5000, threaded=True)
