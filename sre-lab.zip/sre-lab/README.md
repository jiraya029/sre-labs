# SRE Observability Lab

Rebuild of the *SRE Observability Lab — Test Catalog & Dashboards Guide*.

demo-app (Flask) → Prometheus → Alertmanager → **Ansible webhook** → `kubectl rollout restart`,
plus Loki/Promtail logs, Grafana, kube-state-metrics, node-exporter, cAdvisor and an HPA.
Target: Ubuntu VM + k3s (single node).

## Quick start
```bash
./build-images.sh     # builds sre-lab/demo-app + sre-lab/ansible-webhook, imports into k3s (needs docker or BUILDER=podman)
./deploy.sh           # applies k8s/00..14 and the Grafana dashboard, waits for rollouts
./tests/lab-tests.sh K1
```
Grafana `:30300` (admin/admin, anonymous viewer on) · Prometheus `:30090` · Alertmanager `:30093`.
Dashboard: **SRE Lab — Full Observability** (regenerate JSON with `python3 grafana/gen_dashboard.py`, then re-run `deploy.sh`).

## Tests (`./tests/lab-tests.sh <id>`)
| ID | What it proves | Expected |
|----|----------------|----------|
| K1 | Baseline traffic / smoke test (run first, and after any Prometheus restart: storage is emptyDir) | 30× welcome JSON; Request Rate populates in ~10–20 s |
| K2 | Error injection (`/error`, ~30% HTTP 500, ~100 s) | `HighErrorRate` Inactive → Pending → Firing in 1–2 min; log panels spike |
| K3 | Host CPU stress (`stress --cpu 4`, 5 min) | CPU panels spike; `HostHighCpuLoad` fires at >70% for 30 s; pods throttled, not killed |
| K4 | Memory stress (64Mi limit, 150M alloc) | OOMKilled → CrashLoopBackOff → Running |
| K5 | Delete a demo-app pod | ReplicaSet replaces it within seconds |
| K6 | `hey -c 50 -z 300s` against demo-app | HPA target ≫ 50%, replicas 2 → 6, then back to 2 |
| K7 | kube-state-metrics sanity check | one `phase="Running"` line per pod with value 1 |
| A1 | Playbook against a missing deployment | rescue logs `REMEDIATION FAILED…`, play exits non-zero |
| A2 | Playbook against demo-app | restart + waits for rollout; `failed=0` |
| A3 | Full loop: run K2 while tailing webhook logs | `Firing: HighErrorRate -> restarting demo-app in app`, playbook output, `POST /alert … 200`; remediation counters increment |

Demo order (~15–20 min): K1 → K2+A3 → K5 → K4 → K6 → (K3) → `cleanup`.

## Layout
```
demo-app/            Flask app + Dockerfile (/, /error, /health, /metrics)
ansible-webhook/     Flask webhook + remediate.yml + Dockerfile (ansible-core + kubectl)
k8s/                 00-namespaces … 14-hpa.yaml, mem-stress.yaml (K4, not auto-applied)
grafana/             gen_dashboard.py → sre-lab.json (36 panels, 6 rows)
tests/lab-tests.sh   K1–K7, A1–A3, cleanup
```

## Notes
- Only HighErrorRate is mapped to a remediation (`REMEDIATIONS` in `webhook.py`); other alerts are logged and ignored, so a CPU alert never restarts the app.
- node-exporter uses hostNetwork on :9100 — stop any host-level node_exporter first.
- k3s ships metrics-server, which the HPA needs. On other distros install it.
- Kubernetes can show scaled-down demo-app pods as `Error` briefly (Flask dev server ignores SIGTERM). Cosmetic.
