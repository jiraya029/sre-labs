#!/usr/bin/env python3
"""Generates grafana/sre-lab.json (the 'SRE Lab - Full Observability' dashboard)."""
import json, pathlib

PROM = {"type": "prometheus", "uid": "prometheus"}
LOKI = {"type": "loki", "uid": "loki"}
panels, _id = [], [0]
pos = {"x": 0, "y": 0, "h": 0}


def nid():
    _id[0] += 1
    return _id[0]


def _flush():
    if pos["x"] or pos["h"]:
        pos["y"] += pos["h"]
        pos["x"] = pos["h"] = 0


def row(title):
    _flush()
    panels.append({"type": "row", "title": title, "id": nid(), "collapsed": False,
                   "gridPos": {"h": 1, "w": 24, "x": 0, "y": pos["y"]}, "panels": []})
    pos["y"] += 1


def place(w, h):
    if pos["x"] + w > 24:
        _flush()
    gp = {"h": h, "w": w, "x": pos["x"], "y": pos["y"]}
    pos["x"] += w
    pos["h"] = max(pos["h"], h)
    return gp


def targets(items, ds):
    return [{"refId": chr(65 + i), "datasource": ds, "expr": e, "legendFormat": l,
             **({"queryType": "range"} if ds is LOKI else {})} for i, (e, l) in enumerate(items)]


def ts(title, items, w=12, h=8, unit=None, ds=PROM, mn=None, mx=None):
    d = {}
    if unit: d["unit"] = unit
    if mn is not None: d["min"] = mn
    if mx is not None: d["max"] = mx
    panels.append({"type": "timeseries", "title": title, "id": nid(), "datasource": ds,
                   "gridPos": place(w, h), "targets": targets(items, ds),
                   "fieldConfig": {"defaults": d, "overrides": []},
                   "options": {"legend": {"displayMode": "list", "placement": "bottom"},
                               "tooltip": {"mode": "multi"}}})


def stat(title, expr, w=4, h=4, unit=None, steps=None, ds=PROM):
    steps = steps or [{"color": "green", "value": None}]
    d = {"thresholds": {"mode": "absolute", "steps": steps}}
    if unit: d["unit"] = unit
    panels.append({"type": "stat", "title": title, "id": nid(), "datasource": ds,
                   "gridPos": place(w, h), "targets": targets([(expr, "")], ds),
                   "fieldConfig": {"defaults": d, "overrides": []},
                   "options": {"colorMode": "value", "graphMode": "area", "reduceOptions": {"calcs": ["lastNotNull"]}}})


def logs(title, expr, w=24, h=9):
    panels.append({"type": "logs", "title": title, "id": nid(), "datasource": LOKI,
                   "gridPos": place(w, h), "targets": targets([(expr, "")], LOKI),
                   "options": {"showTime": True, "wrapLogMessage": True, "sortOrder": "Descending",
                               "enableLogDetails": True}})


APP = '{namespace="app", app="demo-app"}'
NOT_LOOPBACK = 'device!~"lo|veth.*|cni.*|flannel.*"'
FS = 'fstype!~"tmpfs|overlay|squashfs|ramfs"'

# ---- Demo App - Golden Signals
row("Demo App — Golden Signals")
ts("Request Rate", [('sum(rate(http_requests_total[1m]))', "req/s")], w=8, unit="reqps")
ts("Error Rate", [('sum(rate(http_requests_total{status=~"5.."}[1m])) / sum(rate(http_requests_total[1m])) * 100', "5xx %")],
   w=8, unit="percent", mn=0)
ts("Requests by Status Code", [('sum by (status) (rate(http_requests_total[1m]))', "{{status}}")], w=8, unit="reqps")
ts("Latency Percentiles (p50/p95/p99)",
   [(f'histogram_quantile({q}, sum by (le) (rate(http_request_duration_seconds_bucket[1m])))', f"p{int(q*100)}")
    for q in (0.5, 0.95, 0.99)], w=12, unit="s")
stat("Total Requests", 'sum(http_requests_total)', w=6, h=8)
stat("Demo App Up", 'sum(up{job="demo-app"})', w=6, h=8,
     steps=[{"color": "red", "value": None}, {"color": "green", "value": 1}])

# ---- Node Exporter
row("Node Exporter — Host Health")
stat("Uptime", 'time() - node_boot_time_seconds', w=6, unit="s")
stat("CPU Cores", 'count(count by (cpu) (node_cpu_seconds_total{mode="idle"}))', w=6)
stat("Running Processes", 'node_procs_running', w=6)
stat("Blocked Processes", 'node_procs_blocked', w=6)
ts("CPU Usage %", [('100 - (avg(rate(node_cpu_seconds_total{mode="idle"}[1m])) * 100)', "cpu %")],
   unit="percent", mn=0, mx=100)
ts("CPU Usage by Mode", [('avg by (mode) (rate(node_cpu_seconds_total[1m])) * 100', "{{mode}}")], unit="percent")
ts("Memory Usage %", [('(1 - node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes) * 100', "mem %")],
   unit="percent", mn=0, mx=100)
ts("Memory Detailed", [('node_memory_MemTotal_bytes', "total"), ('node_memory_MemAvailable_bytes', "available"),
                       ('node_memory_Cached_bytes', "cached"), ('node_memory_Buffers_bytes', "buffers")], unit="bytes")
ts("Disk Usage %", [(f'(1 - node_filesystem_avail_bytes{{mountpoint="/",{FS}}} / node_filesystem_size_bytes{{mountpoint="/",{FS}}}) * 100', "/")],
   unit="percent", mn=0, mx=100)
ts("Disk I/O", [('sum(rate(node_disk_read_bytes_total[1m]))', "read"), ('sum(rate(node_disk_written_bytes_total[1m]))', "write")], unit="Bps")
ts("Filesystem Space by Mountpoint", [(f'(1 - node_filesystem_avail_bytes{{{FS}}} / node_filesystem_size_bytes{{{FS}}}) * 100', "{{mountpoint}}")],
   unit="percent", mn=0, mx=100)
ts("Network Traffic", [(f'sum(rate(node_network_receive_bytes_total{{{NOT_LOOPBACK}}}[1m]))', "rx"),
                       (f'sum(rate(node_network_transmit_bytes_total{{{NOT_LOOPBACK}}}[1m]))', "tx")], unit="Bps")
ts("Network Errors & Drops",
   [(f'sum(rate(node_network_receive_errs_total{{{NOT_LOOPBACK}}}[1m])) + sum(rate(node_network_transmit_errs_total{{{NOT_LOOPBACK}}}[1m]))', "errors"),
    (f'sum(rate(node_network_receive_drop_total{{{NOT_LOOPBACK}}}[1m])) + sum(rate(node_network_transmit_drop_total{{{NOT_LOOPBACK}}}[1m]))', "drops")], unit="pps")
ts("Load Average", [('node_load1', "1m"), ('node_load5', "5m"), ('node_load15', "15m")])

# ---- Logs
row("Logs")
logs("All App Logs", APP)
logs("Error Logs Only", APP + ' |~ "(?i)error|failure|\\" 5[0-9][0-9] "')
ts("Log Volume Over Time", [(f'sum(count_over_time({APP}[1m]))', "log lines / min")], w=24, h=6, ds=LOKI)

# ---- Alerting
row("Alerting")
panels.append({"type": "alertlist", "title": "Active Alerts", "id": nid(), "gridPos": place(12, 9),
               "options": {"viewMode": "list", "groupMode": "default", "maxItems": 20, "sortOrder": 1,
                           "dashboardAlerts": False, "showInstances": True, "datasource": "prometheus",
                           "stateFilter": {"firing": True, "pending": True, "noData": False, "normal": False, "error": True}}})
panels.append({"type": "table", "title": "Firing / Pending Alerts (ALERTS metric)", "id": nid(), "datasource": PROM,
               "gridPos": place(12, 9),
               "targets": [{"refId": "A", "datasource": PROM, "expr": 'ALERTS{alertstate=~"firing|pending"}',
                            "instant": True, "format": "table"}],
               "options": {"showHeader": True}})

# ---- Kubernetes Cluster Overview
row("Kubernetes Cluster Overview")
stat("Active Pods (Running)", 'sum(kube_pod_status_phase{phase="Running"})', w=6)
stat("Active Containers", 'sum(kube_pod_container_status_running)', w=6)
ts("Demo App — Desired vs Available Replicas",
   [('kube_deployment_spec_replicas{namespace="app",deployment="demo-app"}', "desired"),
    ('kube_deployment_status_replicas_available{namespace="app",deployment="demo-app"}', "available")], w=12, mn=0)
ts("CPU Usage by Pod (app namespace)",
   [('sum by (pod) (rate(container_cpu_usage_seconds_total{namespace="app",container!="",container!="POD"}[1m]))', "{{pod}}")],
   unit="cores")
ts("Memory Usage by Pod (app namespace)",
   [('sum by (pod) (container_memory_working_set_bytes{namespace="app",container!="",container!="POD"})', "{{pod}}")],
   unit="bytes")
ts("Autoscaling — HPA Current vs Desired Replicas",
   [('kube_horizontalpodautoscaler_status_current_replicas{namespace="app"}', "current"),
    ('kube_horizontalpodautoscaler_status_desired_replicas{namespace="app"}', "desired")], w=24, mn=0)

# ---- Ansible Remediation Activity
row("Ansible Remediation Activity")
stat("Total Remediation Attempts", 'sum(remediation_attempts_total) or vector(0)', w=8)
stat("Successful Remediations", 'sum(remediation_attempts_total{outcome="success"}) or vector(0)', w=8)
stat("Failed Remediations", 'sum(remediation_attempts_total{outcome="failure"}) or vector(0)', w=8,
     steps=[{"color": "green", "value": None}, {"color": "red", "value": 1}])
ts("Remediation Attempts Over Time", [('sum by (alertname, outcome) (remediation_attempts_total)', "{{alertname}} / {{outcome}}")],
   w=24, h=7, mn=0)
logs("Ansible Webhook Logs", '{namespace="monitoring", app="ansible-webhook"}')

dash = {"uid": "sre-lab-full", "title": "SRE Lab — Full Observability", "tags": ["sre-lab"],
        "schemaVersion": 39, "version": 1, "refresh": "10s", "timezone": "browser",
        "time": {"from": "now-30m", "to": "now"}, "templating": {"list": []},
        "annotations": {"list": []}, "panels": panels}
out = pathlib.Path(__file__).with_name("sre-lab.json")
out.write_text(json.dumps(dash, indent=1, ensure_ascii=False))
print(f"wrote {out} ({len([p for p in panels if p['type'] != 'row'])} panels)")
