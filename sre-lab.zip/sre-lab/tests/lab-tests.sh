#!/usr/bin/env bash
# Usage: ./tests/lab-tests.sh <K1..K7|A1|A2|A3|cleanup|list>
set -uo pipefail
cd "$(dirname "$0")/.."
SVC=demo-app.app.svc.cluster.local:5000

webhook_pod() { kubectl get pod -n monitoring -l app=ansible-webhook -o jsonpath='{.items[0].metadata.name}'; }

case "${1:-list}" in
  K1) # Baseline traffic / smoke test
    kubectl run curl-warmup -n app --image=curlimages/curl --restart=Never -- \
      sh -c "for i in \$(seq 1 30); do curl -s $SVC/; sleep 1; done"
    echo "Then: kubectl logs -f curl-warmup -n app" ;;
  K2) # Error-rate injection -> HighErrorRate
    kubectl run curl-test -n app --image=curlimages/curl --restart=Never -- \
      sh -c "for i in \$(seq 1 200); do curl -s $SVC/error; sleep 0.5; done" ;;
  K3) # Host CPU stress -> HostHighCpuLoad
    kubectl run cpu-stress -n app --image=polinux/stress --restart=Never -- \
      stress --cpu 4 --timeout 300s ;;
  K4) # Memory stress -> real OOMKill
    kubectl apply -f k8s/mem-stress.yaml
    echo "Watch: kubectl get pods -n app -w"
    echo "Then:  kubectl describe pod mem-stress -n app | grep -A5 'Last State'" ;;
  K5) # Manual pod deletion -> ReplicaSet self-heals
    POD=$(kubectl get pod -n app -l app=demo-app -o jsonpath='{.items[0].metadata.name}')
    kubectl delete pod "$POD" -n app --wait=false
    kubectl get pods -n app -w ;;
  K6) # Load -> HPA scales 2 -> 6
    kubectl apply -f k8s/14-hpa.yaml
    kubectl run load-gen -n app --image=williamyeh/hey --restart=Never -- \
      -z 300s -c 50 http://$SVC/
    echo "Watch (two terminals): kubectl get hpa -n app -w   |   kubectl get pods -n app -w" ;;
  K7) # kube-state-metrics sanity check
    kubectl delete pod curl-check -n monitoring --ignore-not-found >/dev/null
    kubectl run curl-check -n monitoring --image=curlimages/curl --restart=Never -- \
      curl -s kube-state-metrics.monitoring.svc.cluster.local:8080/metrics
    kubectl wait --for=jsonpath='{.status.phase}'=Succeeded pod/curl-check -n monitoring --timeout=60s
    kubectl logs curl-check -n monitoring | grep 'phase="Running"' ;;
  A1) # Manual failure path (rescue block)
    kubectl exec -n monitoring "$(webhook_pod)" -- ansible-playbook /ansible/playbooks/remediate.yml \
      -i localhost, -c local -e target_namespace=app -e target_deployment=nonexistent-app ;;
  A2) # Manual success path
    kubectl exec -n monitoring "$(webhook_pod)" -- ansible-playbook /ansible/playbooks/remediate.yml \
      -i localhost, -c local -e target_namespace=app -e target_deployment=demo-app
    kubectl get pods -n app ;;
  A3) # End-to-end: run K2 while watching the webhook
    echo "Terminal 1: kubectl logs -n monitoring deployment/ansible-webhook -f"
    echo "Terminal 2: ./tests/lab-tests.sh K2" ;;
  cleanup)
    kubectl delete pod curl-warmup curl-test cpu-stress mem-stress load-gen curl-check -n app --ignore-not-found
    kubectl delete pod curl-check -n monitoring --ignore-not-found ;;
  *) echo "Tests: K1 K2 K3 K4 K5 K6 K7 A1 A2 A3 cleanup"
     echo "Demo order: K1, K2+A3, K5, K4, K6, (K3), cleanup" ;;
esac
