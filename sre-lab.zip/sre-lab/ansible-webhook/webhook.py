"""Alertmanager webhook -> Ansible remediation runner."""
import logging
import os
import subprocess

from flask import Flask, Response, jsonify, request
from prometheus_client import CONTENT_TYPE_LATEST, Counter, generate_latest

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("ansible-webhook")

PLAYBOOK = os.getenv("PLAYBOOK", "/ansible/playbooks/remediate.yml")

# alertname -> what to restart. Alerts not listed here are logged and ignored.
REMEDIATIONS = {
    "HighErrorRate": {"namespace": "app", "deployment": "demo-app"},
}

ATTEMPTS = Counter(
    "remediation_attempts_total",
    "Remediation attempts by alert and outcome",
    ["alertname", "outcome"],
)
for _name in REMEDIATIONS:  # pre-create series so panels show 0 instead of "No data"
    for _outcome in ("success", "failure"):
        ATTEMPTS.labels(_name, _outcome)


def run_playbook(namespace, deployment):
    proc = subprocess.run(
        ["ansible-playbook", PLAYBOOK, "-i", "localhost,", "-c", "local",
         "-e", f"target_namespace={namespace}", "-e", f"target_deployment={deployment}"],
        capture_output=True, text=True,
        env={**os.environ, "ANSIBLE_FORCE_COLOR": "false", "ANSIBLE_LOCALHOST_WARNING": "false",
             "ANSIBLE_INVENTORY_UNPARSED_WARNING": "false"},
    )
    print(proc.stdout, flush=True)
    if proc.stderr:
        print(proc.stderr, flush=True)
    return proc.returncode == 0


@app.route("/alert", methods=["POST"])
def alert():
    payload = request.get_json(force=True, silent=True) or {}
    failed = False
    for a in payload.get("alerts", []):
        name = a.get("labels", {}).get("alertname", "unknown")
        if a.get("status") != "firing":
            log.info("Ignoring %s alert: %s", a.get("status"), name)
            continue
        target = REMEDIATIONS.get(name)
        if not target:
            log.info("Firing: %s -> no remediation mapped, ignoring", name)
            continue
        log.info("Firing: %s -> restarting %s in %s", name, target["deployment"], target["namespace"])
        ok = run_playbook(target["namespace"], target["deployment"])
        ATTEMPTS.labels(name, "success" if ok else "failure").inc()
        failed = failed or not ok
    return (jsonify(status="remediation failed"), 500) if failed else (jsonify(status="ok"), 200)


@app.route("/health")
def health():
    return jsonify(status="healthy")


@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
