#!/usr/bin/env bash
# Deploys the whole lab. Run ./build-images.sh first.
set -euo pipefail
cd "$(dirname "$0")"

kubectl apply -f k8s/00-namespaces.yaml
kubectl create configmap grafana-dashboards -n monitoring \
  --from-file=sre-lab.json=grafana/sre-lab.json --dry-run=client -o yaml | kubectl apply -f -

for f in k8s/[0-9][0-9]-*.yaml; do
  [ "$f" = "k8s/00-namespaces.yaml" ] && continue
  echo ">> applying $f"; kubectl apply -f "$f"
done

echo ">> waiting for rollouts"
for d in demo-app; do kubectl rollout status deploy/$d -n app --timeout=180s; done
for d in prometheus alertmanager loki grafana kube-state-metrics ansible-webhook; do
  kubectl rollout status deploy/$d -n monitoring --timeout=180s
done
kubectl rollout status ds/node-exporter -n monitoring --timeout=120s
kubectl rollout status ds/promtail -n monitoring --timeout=120s

NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
echo
echo "Grafana       http://$NODE_IP:30300   (admin / admin)"
echo "Prometheus    http://$NODE_IP:30090"
echo "Alertmanager  http://$NODE_IP:30093"
echo "Next: ./tests/lab-tests.sh K1"
